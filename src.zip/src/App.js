import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

import Profile from "./components/Perfil";
import Registro from "./components/Registro";
import UserManagement from "./components/LogIn";

function App() {
  return (
    <Router>
      <nav>
        <Link to="/Perfil">Perfil </Link>
        <Link to="/Registro">Registro </Link>
        <Link to="/LogIn">LogIn </Link>
      </nav>
      <Routes>
        <Route path="/Perfil" element={<Profile />} />
        <Route path="/Registro" element={<Registro />} />
        <Route path="/LogIn" element={<UserManagement />} />
      </Routes>
    </Router>
  );
}

export default App;
