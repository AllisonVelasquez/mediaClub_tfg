<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\UsuarioRepository;

#[ORM\Entity(repositoryClass: UsuarioRepository::class)]
#[ORM\Table(name: "usuario")]
#[ORM\UniqueConstraint(name: "UNIQ_8D93D64990D7219F", columns: ["eoid"])]
#[ORM\UniqueConstraint(name: "UNIQ_8D93D649F85E0677", columns: ["username"])]
class Usuario
{
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: "IDENTITY")]
    #[ORM\Column(type: "integer", nullable: false)]
    private ?int $id = null;

    #[ORM\Column(type: "string", length: 100, nullable: false)]
    private string $eoid;

    #[ORM\Column(type: "string", length: 100, nullable: true)]
    private ?string $name = null;

    #[ORM\Column(type: "string", length: 100, nullable: true)]
    private ?string $surname = null;

    #[ORM\Column(type: "string", length: 50, nullable: true)]
    private ?string $mail = null;

    #[ORM\Column(type: "string", length: 100, nullable: false)]
    private string $username;

    #[ORM\Column(type: "string", length: 20, nullable: true)]
    private ?string $mobile = null;

    #[ORM\Column(type: "string", length: 100, nullable: true)]
    private ?string $password = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEoid(): ?string
    {
        return $this->eoid;
    }

    public function setEoid(string $eoid): self
    {
        $this->eoid = $eoid;
        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): self
    {
        $this->name = $name;
        return $this;
    }

    public function getSurname(): ?string
    {
        return $this->surname;
    }

    public function setSurname(?string $surname): self
    {
        $this->surname = $surname;
        return $this;
    }

    public function getMail(): ?string
    {
        return $this->mail;
    }

    public function setMail(?string $mail): self
    {
        $this->mail = $mail;
        return $this;
    }

    public function getUsername(): ?string
    {
        return $this->username;
    }

    public function setUsername(string $username): self
    {
        $this->username = $username;
        return $this;
    }

    public function getMobile(): ?string
    {
        return $this->mobile;
    }

    public function setMobile(?string $mobile): self
    {
        $this->mobile = $mobile;
        return $this;
    }

    public function getPassword(): ?string
    {
        return $this->password;
    }

    public function setPassword(?string $password): self
    {
        $this->password = $password;
        return $this;
    }

    public function __toString(): string
    {
        return $this->getUsername();
    }
}
