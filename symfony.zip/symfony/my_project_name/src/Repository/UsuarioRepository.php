<?php


namespace App\Repository;

use App\Entity\Usuario;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Doctrine\ORM\EntityManagerInterface;

/**
 * @extends ServiceEntityRepository<Usuario>
 */
class UsuarioRepository extends ServiceEntityRepository
{
    private EntityManagerInterface $em;

    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Usuario::class);
        $this->em = $this->getEntityManager(); // Mejor forma para acceder al EM
    }

    /**
     * Guarda un usuario en la base de datos.
     */
    public function guardar(Usuario $usuario, bool $flush = true): void
    {
        $this->em->persist($usuario);

        if ($flush) {
            $this->em->flush();
        }
    }

    /**
     * Elimina un usuario de la base de datos.
     */
    public function eliminar(Usuario $usuario, bool $flush = true): void
    {
        $this->em->remove($usuario);

        if ($flush) {
            $this->em->flush();
        }
    }
    public function usuarios():array
    {
       return $this->findAll();
    }
}
