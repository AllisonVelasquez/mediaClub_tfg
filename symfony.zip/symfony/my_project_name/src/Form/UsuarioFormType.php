<?php
namespace App\Form;

use App\Entity\Usuario;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\OptionsResolver\OptionsResolver;

class UsuarioType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('eoid', TextType::class)
            ->add('name', TextType::class)
            ->add('surname', TextType::class)
            ->add('mail', TextType::class)
            ->add('username', TextType::class)
            ->add('mobile', TextType::class)
            ->add('password', TextType::class) 
            // ojo: esto es sin codificar aún
        ;
    }

   
}
