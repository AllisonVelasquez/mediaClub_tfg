<?php
namespace App\Controller;

use App\Entity\Usuario;
use App\Form\UsuarioType;
use App\Repository\UsuarioRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class GestionUsuarios extends AbstractController
{
    #[Route('nuevo', name: 'usuario_nuevo')]
    public function nuevo(Request $request, UsuarioRepository $usuarioRepository): Response
    {
        $usuario = new Usuario();
        $form = $this->createForm(UsuarioType::class, $usuario);
        $form->handleRequest($request);
    
        if ($form->isSubmitted() && $form->isValid()) {
            $usuarioRepository->guardar($usuario); // Aquí ya está con los datos del form
            return $this->redirectToRoute('listar_usuarios');
        }
    
        return $this->render('/base.html.twig', [
            'form' => $form->createView(),
        ]);
    }
    #[Route('listar_usuarios', name: 'listar_usuarios')]
    function listar( UsuarioRepository $usuarioRepository){
       $usuario= $usuarioRepository->usuarios();
        return $this->render('/listarUsuarios.html.twig', [
            'usuario' => $usuario,
        ]);
    }

    #[Route('usuario_detalle/{$id}', name: 'usuario_detalle')]
    public function detalle(Usuario $usuario): Response
    {
        return $this->render('/detalle.html.twig', [
            'usuario' => $usuario,
        ]);
    }
}
?>