<?php
// src/Controller/DatabaseController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\DBAL\Connection;

class DatabaseController extends AbstractController
{
    private $connection,$database='bd';
    

    public function __construct(Connection $connection)
    {
        $this->connection = $connection;
    }

    /**
     * @Route("/create_db/{nombre}", name="create_db", methods={"GET"})
     */
    public function createDatabase($nombre): Response
    {
        try {
            // Crear una nueva base de datos
            $this->connection->executeStatement('CREATE DATABASE IF NOT EXISTS '. $this->database .'');
            return new Response('Base de datos creada exitosamente. Gracias por la esper '. $nombre );
        } catch (\Exception $e) {
            return new Response('Error al crear la base de datos: ' . $e->getMessage());
        }
    }

    /**
     * @Route("/insert_data", name="insert_data")
     */
    public function insertData(): Response
    {
        try {
            // Seleccionar la base de datos que quieres usar
            $this->connection->executeStatement('USE '.$this->database.'');

            // Crear una tabla
            $this->connection->executeStatement('CREATE TABLE IF NOT EXISTS usersteste (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100),
                email VARCHAR(100)
            )');

            // Insertar un nuevo registro
            $this->connection->insert('usersteste', [
                'name' => 'Juan Perez',
                'email' => 'juan@example.com'
            ]);

            return new Response('Datos insertados correctamente.');
        } catch (\Exception $e) {
            return new Response('Error al insertar datos: ' . $e->getMessage());
        }
    }

    /**
     * @Route("/select_data", name="select_data", methods={"GET"})
     */
    public function selectData(): Response
    {
        try {
            // Seleccionar la base de datos
            $this->connection->executeStatement('USE '.$this->database.'');

            // Consultar datos de la tabla 'usersteste'
            $query = 'SELECT * FROM usersteste';
            $result = $this->connection->fetchAllAssociative($query);

            $output = '<h1>Usuarios</h1><ul>';
            foreach ($result as $row) {
                $output .= '<li>' . $row['name'] . ' - ' . $row['email'] . '</li>';
            }
            $output .= '</ul>';

            return new Response($output);
        } catch (\Exception $e) {
            return new Response('Error al obtener datos: ' . $e->getMessage());
        }
    }
}
