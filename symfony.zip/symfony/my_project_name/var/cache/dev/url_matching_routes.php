<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/insert_data' => [[['_route' => 'insert_data', '_controller' => 'App\\Controller\\DatabaseController::insertData'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/select_data' => [[['_route' => 'select_data', '_controller' => 'App\\Controller\\DatabaseController::selectData'], null, ['GET' => 0], null, false, false, null]],
        '/usuario_nuevo' => [[['_route' => 'usuario_nuevo', '_controller' => 'App\\Controller\\GestionUsuarios::nuevo'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/listar_usuarios' => [[['_route' => 'listar_usuarios', '_controller' => 'App\\Controller\\GestionUsuarios::listar'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/create_db/([^/]++)(*:61)'
                .'|/usuario_detalle/([^/]++)(*:93)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        61 => [[['_route' => 'create_db', '_controller' => 'App\\Controller\\DatabaseController::createDatabase'], ['nombre'], ['GET' => 0], null, false, true, null]],
        93 => [
            [['_route' => 'usuario_detalle', '_controller' => 'App\\Controller\\GestionUsuarios::detalle'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
