<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* detalle.html.twig */
class __TwigTemplate_01f8aae30cbd86242b748b57d67dbaf6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "detalle.html.twig"));

        // line 1
        yield "<style>
        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse; /* Hace que las celdas compartan los bordes */
        }

        table, th, td {
            border: 1px solid black; /* Añade un borde alrededor de la tabla y las celdas */
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>

";
        // line 22
        yield from $this->unwrap()->yieldBlock('body', $context, $blocks);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 23
        yield " 
</head>
<body>
    <div class=\"container\">
        <h1>Detalles del Usuario</h1>

        <!-- Tabla con bordes -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>EOID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Correo</th>
                    <th>Usuario</th>
                    <th>Móvil</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>";
        // line 44
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 44, $this->source); })()), "id", [], "any", false, false, false, 44), "html", null, true);
        yield "</td>
                    <td>";
        // line 45
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 45, $this->source); })()), "eoid", [], "any", false, false, false, 45), "html", null, true);
        yield "</td>
                    <td>";
        // line 46
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 46, $this->source); })()), "name", [], "any", false, false, false, 46), "html", null, true);
        yield "</td>
                    <td>";
        // line 47
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 47, $this->source); })()), "surname", [], "any", false, false, false, 47), "html", null, true);
        yield "</td>
                    <td>";
        // line 48
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 48, $this->source); })()), "mail", [], "any", false, false, false, 48), "html", null, true);
        yield "</td>
                    <td>";
        // line 49
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 49, $this->source); })()), "username", [], "any", false, false, false, 49), "html", null, true);
        yield "</td>
                    <td>";
        // line 50
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["usuario"]) || array_key_exists("usuario", $context) ? $context["usuario"] : (function () { throw new RuntimeError('Variable "usuario" does not exist.', 50, $this->source); })()), "mobile", [], "any", false, false, false, 50), "html", null, true);
        yield "</td>
                </tr>
            </tbody>
        </table>


    <a href=\"";
        // line 56
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("usuario_nuevo");
        yield "\" class=\"btn btn-primary\">Crear Nuevo Usuario</a>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "detalle.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  142 => 56,  133 => 50,  129 => 49,  125 => 48,  121 => 47,  117 => 46,  113 => 45,  109 => 44,  86 => 23,  69 => 22,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<style>
        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse; /* Hace que las celdas compartan los bordes */
        }

        table, th, td {
            border: 1px solid black; /* Añade un borde alrededor de la tabla y las celdas */
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>

{% block body %}
 
</head>
<body>
    <div class=\"container\">
        <h1>Detalles del Usuario</h1>

        <!-- Tabla con bordes -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>EOID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Correo</th>
                    <th>Usuario</th>
                    <th>Móvil</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ usuario.id }}</td>
                    <td>{{ usuario.eoid }}</td>
                    <td>{{ usuario.name }}</td>
                    <td>{{ usuario.surname }}</td>
                    <td>{{ usuario.mail }}</td>
                    <td>{{ usuario.username }}</td>
                    <td>{{ usuario.mobile }}</td>
                </tr>
            </tbody>
        </table>


    <a href=\"{{ path('usuario_nuevo') }}\" class=\"btn btn-primary\">Crear Nuevo Usuario</a>
{% endblock %}
", "detalle.html.twig", "/var/www/symfony/my_project_name/templates/detalle.html.twig");
    }
}
